﻿Imports System.Data
Imports System.Data.SqlClient

Public Class COA

    'Drop down
    Private Sub ButtonCOA_Click(sender As Object, e As EventArgs) Handles ButtonCOA.Click
        ContextMenuStrip1.Show(ButtonCOA, 0, ButtonCOA.Height)

        ContextMenuStrip1.ForeColor = Color.White


    End Sub

    Sub GridLoad()
        Try

            adapter = New SqlDataAdapter("SELECT MA.Account_Code, SA.Sub_Code, MA.Account_Name, SA.Sub_AC_Name, MA.Type, MA.Sub_Type FROM Main_Account MA LEFT JOIN Sub_Account SA ON MA.Account_Code = SA.Main_Code ORDER BY Account_Code", connect)

            Dim dTable As New DataTable
            adapter.Fill(dTable)

            DataGridViewJoin.DataSource = dTable

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub

    Sub datagridDesign()

        DataGridViewJoin.ColumnHeadersDefaultCellStyle.Font = New Font("Arial", 9, FontStyle.Bold)

        DataGridViewJoin.BackgroundColor = Color.White
        DataGridViewJoin.DefaultCellStyle.SelectionBackColor = Color.Yellow
        DataGridViewJoin.DefaultCellStyle.SelectionForeColor = Color.Black
        DataGridViewJoin.SelectionMode = DataGridViewSelectionMode.FullRowSelect

        DataGridViewJoin.DefaultCellStyle.WrapMode = DataGridViewTriState.False

        DataGridViewJoin.AllowUserToResizeColumns = True
        DataGridViewJoin.AllowUserToAddRows = False
        DataGridViewJoin.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill

        DataGridViewJoin.RowsDefaultCellStyle.BackColor = Color.Bisque
        DataGridViewJoin.AlternatingRowsDefaultCellStyle.BackColor = Color.WhiteSmoke

    End Sub

    Private Sub MainAccountToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles MainAccountToolStripMenuItem.Click
        With MainAccount
            .TopLevel = False
            PanelMain.Controls.Add(MainAccount)
            .BringToFront()
            .Show()

            SubAccount.Dispose()
            DataGridViewJoin.Visible = False

        End With
    End Sub

    Private Sub SubAccountToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SubAccountToolStripMenuItem.Click
        With SubAccount
            .TopLevel = False
            PanelMain.Controls.Add(SubAccount)
            .BringToFront()
            .Show()

            MainAccount.Dispose()
            DataGridViewJoin.Visible = False

        End With
    End Sub

    Private Sub COA_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        
        datagridDesign()
        GridLoad()

    End Sub

    Private Sub ButtonHome_Click(sender As Object, e As EventArgs) Handles ButtonHome.Click
        MainAccount.Dispose()
        SubAccount.Dispose()
        DataGridViewJoin.Visible = True

        GridLoad()
    End Sub

   
    Private Sub TextBoxSearch_TextChanged(sender As Object, e As EventArgs) Handles TextBoxSearch.TextChanged
        Dim getSearch As New DataTable

        adapter = New SqlDataAdapter("SELECT MA.Account_Code, SA.Sub_Code, MA.Account_Name, SA.Sub_AC_Name, MA.Type, MA.Sub_Type FROM Main_Account MA LEFT JOIN Sub_Account SA ON MA.Account_Code = SA.Main_Code WHERE MA.Account_Code LIKE '%" & TextBoxSearch.Text & "%' or Sub_Code LIKE '%" & TextBoxSearch.Text & "%' or Account_Name LIKE '%" & TextBoxSearch.Text & "%' or Sub_AC_Name LIKE '%" & TextBoxSearch.Text & "%' or Type LIKE '%" & TextBoxSearch.Text & "%' or Sub_Type LIKE '%" & TextBoxSearch.Text & "%' ORDER BY Account_Code", connect)

        adapter.Fill(getSearch)

        DataGridViewJoin.DataSource = getSearch

    End Sub

    Private Sub DataGridViewJoin_ColumnAdded(sender As Object, e As DataGridViewColumnEventArgs) Handles DataGridViewJoin.ColumnAdded
        e.Column.SortMode = DataGridViewColumnSortMode.NotSortable
    End Sub
End Class
