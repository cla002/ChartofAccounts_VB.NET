﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class SubAccount
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.PanelSubHeader = New System.Windows.Forms.Panel()
        Me.ButtonAddSub = New System.Windows.Forms.Button()
        Me.ButtonClose = New System.Windows.Forms.Button()
        Me.PaneSubForm = New System.Windows.Forms.Panel()
        Me.ComboBoxName = New System.Windows.Forms.ComboBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.ComboBoxCode = New System.Windows.Forms.ComboBox()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.ButtonDelete = New System.Windows.Forms.Button()
        Me.ButtonEdit = New System.Windows.Forms.Button()
        Me.ButtonSave = New System.Windows.Forms.Button()
        Me.ButtonClear = New System.Windows.Forms.Button()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.TextBoxSubAccName = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.TextBoxSubCode = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.ButtonSearch = New System.Windows.Forms.Button()
        Me.TextBoxSubSearch = New System.Windows.Forms.TextBox()
        Me.DataGridViewSub = New System.Windows.Forms.DataGridView()
        Me.PanelSubGrid = New System.Windows.Forms.Panel()
        Me.LabelSubType = New System.Windows.Forms.Label()
        Me.LabelType = New System.Windows.Forms.Label()
        Me.PanelSubHeader.SuspendLayout()
        Me.PaneSubForm.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.DataGridViewSub, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PanelSubGrid.SuspendLayout()
        Me.SuspendLayout()
        '
        'PanelSubHeader
        '
        Me.PanelSubHeader.BackColor = System.Drawing.SystemColors.Control
        Me.PanelSubHeader.Controls.Add(Me.ButtonAddSub)
        Me.PanelSubHeader.Controls.Add(Me.ButtonClose)
        Me.PanelSubHeader.Dock = System.Windows.Forms.DockStyle.Right
        Me.PanelSubHeader.Location = New System.Drawing.Point(510, 0)
        Me.PanelSubHeader.Name = "PanelSubHeader"
        Me.PanelSubHeader.Size = New System.Drawing.Size(191, 31)
        Me.PanelSubHeader.TabIndex = 2
        '
        'ButtonAddSub
        '
        Me.ButtonAddSub.BackColor = System.Drawing.SystemColors.HotTrack
        Me.ButtonAddSub.Cursor = System.Windows.Forms.Cursors.Hand
        Me.ButtonAddSub.FlatAppearance.BorderSize = 0
        Me.ButtonAddSub.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ButtonAddSub.Font = New System.Drawing.Font("Verdana Pro", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonAddSub.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.ButtonAddSub.Location = New System.Drawing.Point(29, 2)
        Me.ButtonAddSub.Name = "ButtonAddSub"
        Me.ButtonAddSub.Size = New System.Drawing.Size(159, 26)
        Me.ButtonAddSub.TabIndex = 11
        Me.ButtonAddSub.Text = "Add Sub Account"
        Me.ButtonAddSub.UseVisualStyleBackColor = False
        '
        'ButtonClose
        '
        Me.ButtonClose.BackColor = System.Drawing.Color.Red
        Me.ButtonClose.Cursor = System.Windows.Forms.Cursors.Hand
        Me.ButtonClose.FlatAppearance.BorderSize = 0
        Me.ButtonClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ButtonClose.Font = New System.Drawing.Font("Verdana Pro", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonClose.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.ButtonClose.Location = New System.Drawing.Point(29, 2)
        Me.ButtonClose.Name = "ButtonClose"
        Me.ButtonClose.Size = New System.Drawing.Size(159, 26)
        Me.ButtonClose.TabIndex = 12
        Me.ButtonClose.Text = "Close Form"
        Me.ButtonClose.UseVisualStyleBackColor = False
        '
        'PaneSubForm
        '
        Me.PaneSubForm.Controls.Add(Me.LabelType)
        Me.PaneSubForm.Controls.Add(Me.LabelSubType)
        Me.PaneSubForm.Controls.Add(Me.ComboBoxName)
        Me.PaneSubForm.Controls.Add(Me.Label10)
        Me.PaneSubForm.Controls.Add(Me.Label8)
        Me.PaneSubForm.Controls.Add(Me.Label6)
        Me.PaneSubForm.Controls.Add(Me.ComboBoxCode)
        Me.PaneSubForm.Controls.Add(Me.Panel1)
        Me.PaneSubForm.Controls.Add(Me.Label5)
        Me.PaneSubForm.Controls.Add(Me.TextBoxSubAccName)
        Me.PaneSubForm.Controls.Add(Me.Label4)
        Me.PaneSubForm.Controls.Add(Me.TextBoxSubCode)
        Me.PaneSubForm.Controls.Add(Me.Label3)
        Me.PaneSubForm.Controls.Add(Me.Label2)
        Me.PaneSubForm.Controls.Add(Me.Label1)
        Me.PaneSubForm.Dock = System.Windows.Forms.DockStyle.Left
        Me.PaneSubForm.Location = New System.Drawing.Point(0, 0)
        Me.PaneSubForm.Name = "PaneSubForm"
        Me.PaneSubForm.Size = New System.Drawing.Size(482, 500)
        Me.PaneSubForm.TabIndex = 3
        '
        'ComboBoxName
        '
        Me.ComboBoxName.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBoxName.FormattingEnabled = True
        Me.ComboBoxName.Location = New System.Drawing.Point(45, 148)
        Me.ComboBoxName.Name = "ComboBoxName"
        Me.ComboBoxName.Size = New System.Drawing.Size(206, 24)
        Me.ComboBoxName.TabIndex = 23
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.ForeColor = System.Drawing.Color.Red
        Me.Label10.Location = New System.Drawing.Point(462, 264)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(13, 17)
        Me.Label10.TabIndex = 22
        Me.Label10.Text = "*"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.Color.Red
        Me.Label8.Location = New System.Drawing.Point(257, 148)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(13, 17)
        Me.Label8.TabIndex = 20
        Me.Label8.Text = "*"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.Red
        Me.Label6.Location = New System.Drawing.Point(215, 91)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(13, 17)
        Me.Label6.TabIndex = 19
        Me.Label6.Text = "*"
        '
        'ComboBoxCode
        '
        Me.ComboBoxCode.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBoxCode.FormattingEnabled = True
        Me.ComboBoxCode.Location = New System.Drawing.Point(45, 91)
        Me.ComboBoxCode.Name = "ComboBoxCode"
        Me.ComboBoxCode.Size = New System.Drawing.Size(164, 24)
        Me.ComboBoxCode.TabIndex = 17
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.ButtonDelete)
        Me.Panel1.Controls.Add(Me.ButtonEdit)
        Me.Panel1.Controls.Add(Me.ButtonSave)
        Me.Panel1.Controls.Add(Me.ButtonClear)
        Me.Panel1.Location = New System.Drawing.Point(45, 321)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(388, 35)
        Me.Panel1.TabIndex = 16
        '
        'ButtonDelete
        '
        Me.ButtonDelete.BackColor = System.Drawing.Color.Red
        Me.ButtonDelete.Cursor = System.Windows.Forms.Cursors.Hand
        Me.ButtonDelete.Dock = System.Windows.Forms.DockStyle.Left
        Me.ButtonDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ButtonDelete.Font = New System.Drawing.Font("Verdana Pro", 11.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonDelete.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.ButtonDelete.Location = New System.Drawing.Point(291, 0)
        Me.ButtonDelete.Name = "ButtonDelete"
        Me.ButtonDelete.Size = New System.Drawing.Size(97, 35)
        Me.ButtonDelete.TabIndex = 9
        Me.ButtonDelete.Text = "Delete"
        Me.ButtonDelete.UseVisualStyleBackColor = False
        '
        'ButtonEdit
        '
        Me.ButtonEdit.BackColor = System.Drawing.Color.OrangeRed
        Me.ButtonEdit.Cursor = System.Windows.Forms.Cursors.Hand
        Me.ButtonEdit.Dock = System.Windows.Forms.DockStyle.Left
        Me.ButtonEdit.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ButtonEdit.Font = New System.Drawing.Font("Verdana Pro", 11.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonEdit.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.ButtonEdit.Location = New System.Drawing.Point(194, 0)
        Me.ButtonEdit.Name = "ButtonEdit"
        Me.ButtonEdit.Size = New System.Drawing.Size(97, 35)
        Me.ButtonEdit.TabIndex = 11
        Me.ButtonEdit.Text = "Edit"
        Me.ButtonEdit.UseVisualStyleBackColor = False
        '
        'ButtonSave
        '
        Me.ButtonSave.BackColor = System.Drawing.Color.Blue
        Me.ButtonSave.Cursor = System.Windows.Forms.Cursors.Hand
        Me.ButtonSave.Dock = System.Windows.Forms.DockStyle.Left
        Me.ButtonSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ButtonSave.Font = New System.Drawing.Font("Verdana Pro", 11.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonSave.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.ButtonSave.Location = New System.Drawing.Point(97, 0)
        Me.ButtonSave.Name = "ButtonSave"
        Me.ButtonSave.Size = New System.Drawing.Size(97, 35)
        Me.ButtonSave.TabIndex = 10
        Me.ButtonSave.Text = "Save"
        Me.ButtonSave.UseVisualStyleBackColor = False
        '
        'ButtonClear
        '
        Me.ButtonClear.BackColor = System.Drawing.Color.DarkGreen
        Me.ButtonClear.Cursor = System.Windows.Forms.Cursors.Hand
        Me.ButtonClear.Dock = System.Windows.Forms.DockStyle.Left
        Me.ButtonClear.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ButtonClear.Font = New System.Drawing.Font("Verdana Pro", 11.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonClear.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.ButtonClear.Location = New System.Drawing.Point(0, 0)
        Me.ButtonClear.Name = "ButtonClear"
        Me.ButtonClear.Size = New System.Drawing.Size(97, 35)
        Me.ButtonClear.TabIndex = 8
        Me.ButtonClear.Text = "Clear"
        Me.ButtonClear.UseVisualStyleBackColor = False
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Verdana Pro", 17.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(148, 31)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(172, 28)
        Me.Label5.TabIndex = 12
        Me.Label5.Text = "Sub Account"
        '
        'TextBoxSubAccName
        '
        Me.TextBoxSubAccName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextBoxSubAccName.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxSubAccName.Location = New System.Drawing.Point(45, 264)
        Me.TextBoxSubAccName.Name = "TextBoxSubAccName"
        Me.TextBoxSubAccName.Size = New System.Drawing.Size(411, 23)
        Me.TextBoxSubAccName.TabIndex = 7
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Verdana Pro SemiBold", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(42, 246)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(101, 15)
        Me.Label4.TabIndex = 6
        Me.Label4.Text = "Sub A/C Name"
        '
        'TextBoxSubCode
        '
        Me.TextBoxSubCode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextBoxSubCode.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxSubCode.Location = New System.Drawing.Point(45, 208)
        Me.TextBoxSubCode.Name = "TextBoxSubCode"
        Me.TextBoxSubCode.Size = New System.Drawing.Size(411, 23)
        Me.TextBoxSubCode.TabIndex = 5
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Verdana Pro SemiBold", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(42, 190)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(68, 15)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "Sub Code"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Verdana Pro SemiBold", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label2.Location = New System.Drawing.Point(42, 73)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(75, 15)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Main Code"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Verdana Pro SemiBold", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(42, 130)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(108, 15)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Main A/C Name"
        '
        'ButtonSearch
        '
        Me.ButtonSearch.BackColor = System.Drawing.Color.Gainsboro
        Me.ButtonSearch.Cursor = System.Windows.Forms.Cursors.Hand
        Me.ButtonSearch.Font = New System.Drawing.Font("Verdana Pro Cond", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonSearch.Location = New System.Drawing.Point(228, 3)
        Me.ButtonSearch.Name = "ButtonSearch"
        Me.ButtonSearch.Size = New System.Drawing.Size(85, 25)
        Me.ButtonSearch.TabIndex = 15
        Me.ButtonSearch.Text = "Search"
        Me.ButtonSearch.UseVisualStyleBackColor = False
        '
        'TextBoxSubSearch
        '
        Me.TextBoxSubSearch.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextBoxSubSearch.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxSubSearch.Location = New System.Drawing.Point(6, 3)
        Me.TextBoxSubSearch.Name = "TextBoxSubSearch"
        Me.TextBoxSubSearch.Size = New System.Drawing.Size(216, 23)
        Me.TextBoxSubSearch.TabIndex = 14
        '
        'DataGridViewSub
        '
        Me.DataGridViewSub.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridViewSub.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.DataGridViewSub.Location = New System.Drawing.Point(0, 31)
        Me.DataGridViewSub.Name = "DataGridViewSub"
        Me.DataGridViewSub.Size = New System.Drawing.Size(701, 469)
        Me.DataGridViewSub.TabIndex = 4
        '
        'PanelSubGrid
        '
        Me.PanelSubGrid.Controls.Add(Me.PanelSubHeader)
        Me.PanelSubGrid.Controls.Add(Me.DataGridViewSub)
        Me.PanelSubGrid.Controls.Add(Me.ButtonSearch)
        Me.PanelSubGrid.Controls.Add(Me.TextBoxSubSearch)
        Me.PanelSubGrid.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PanelSubGrid.Location = New System.Drawing.Point(482, 0)
        Me.PanelSubGrid.Name = "PanelSubGrid"
        Me.PanelSubGrid.Size = New System.Drawing.Size(701, 500)
        Me.PanelSubGrid.TabIndex = 5
        '
        'LabelSubType
        '
        Me.LabelSubType.AutoSize = True
        Me.LabelSubType.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelSubType.Location = New System.Drawing.Point(156, 130)
        Me.LabelSubType.Name = "LabelSubType"
        Me.LabelSubType.Size = New System.Drawing.Size(0, 13)
        Me.LabelSubType.TabIndex = 24
        '
        'LabelType
        '
        Me.LabelType.AutoSize = True
        Me.LabelType.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelType.Location = New System.Drawing.Point(123, 75)
        Me.LabelType.Name = "LabelType"
        Me.LabelType.Size = New System.Drawing.Size(0, 13)
        Me.LabelType.TabIndex = 25
        '
        'SubAccount
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.ClientSize = New System.Drawing.Size(1183, 500)
        Me.Controls.Add(Me.PanelSubGrid)
        Me.Controls.Add(Me.PaneSubForm)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "SubAccount"
        Me.ShowIcon = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.PanelSubHeader.ResumeLayout(False)
        Me.PaneSubForm.ResumeLayout(False)
        Me.PaneSubForm.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        CType(Me.DataGridViewSub, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PanelSubGrid.ResumeLayout(False)
        Me.PanelSubGrid.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents PanelSubHeader As System.Windows.Forms.Panel
    Friend WithEvents ButtonAddSub As System.Windows.Forms.Button
    Friend WithEvents ButtonClose As System.Windows.Forms.Button
    Friend WithEvents PaneSubForm As System.Windows.Forms.Panel
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents ButtonSave As System.Windows.Forms.Button
    Friend WithEvents ButtonClear As System.Windows.Forms.Button
    Friend WithEvents ButtonDelete As System.Windows.Forms.Button
    Friend WithEvents ButtonEdit As System.Windows.Forms.Button
    Friend WithEvents ButtonSearch As System.Windows.Forms.Button
    Friend WithEvents TextBoxSubSearch As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents TextBoxSubAccName As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents TextBoxSubCode As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents DataGridViewSub As System.Windows.Forms.DataGridView
    Friend WithEvents PanelSubGrid As System.Windows.Forms.Panel
    Friend WithEvents ComboBoxCode As System.Windows.Forms.ComboBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents ComboBoxName As System.Windows.Forms.ComboBox
    Friend WithEvents LabelSubType As System.Windows.Forms.Label
    Friend WithEvents LabelType As System.Windows.Forms.Label
End Class
