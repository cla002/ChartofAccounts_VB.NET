﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class COA
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.PanelMenu = New System.Windows.Forms.Panel()
        Me.ButtonCOA = New System.Windows.Forms.Button()
        Me.ButtonHome = New System.Windows.Forms.Button()
        Me.ContextMenuStrip1 = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.MainAccountToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SubAccountToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PanelMain = New System.Windows.Forms.Panel()
        Me.TextBoxSearch = New System.Windows.Forms.TextBox()
        Me.DataGridViewJoin = New System.Windows.Forms.DataGridView()
        Me.PanelMenu.SuspendLayout()
        Me.ContextMenuStrip1.SuspendLayout()
        Me.PanelMain.SuspendLayout()
        CType(Me.DataGridViewJoin, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'PanelMenu
        '
        Me.PanelMenu.BackColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(111, Byte), Integer))
        Me.PanelMenu.Controls.Add(Me.ButtonCOA)
        Me.PanelMenu.Controls.Add(Me.ButtonHome)
        Me.PanelMenu.Dock = System.Windows.Forms.DockStyle.Top
        Me.PanelMenu.Location = New System.Drawing.Point(0, 0)
        Me.PanelMenu.Name = "PanelMenu"
        Me.PanelMenu.Size = New System.Drawing.Size(1184, 28)
        Me.PanelMenu.TabIndex = 2
        '
        'ButtonCOA
        '
        Me.ButtonCOA.BackColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(111, Byte), Integer))
        Me.ButtonCOA.Cursor = System.Windows.Forms.Cursors.Hand
        Me.ButtonCOA.Dock = System.Windows.Forms.DockStyle.Left
        Me.ButtonCOA.FlatAppearance.BorderSize = 0
        Me.ButtonCOA.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ButtonCOA.Font = New System.Drawing.Font("Verdana Pro", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonCOA.ForeColor = System.Drawing.SystemColors.Control
        Me.ButtonCOA.Location = New System.Drawing.Point(67, 0)
        Me.ButtonCOA.Name = "ButtonCOA"
        Me.ButtonCOA.Size = New System.Drawing.Size(200, 28)
        Me.ButtonCOA.TabIndex = 3
        Me.ButtonCOA.Text = "Chart of Accounts"
        Me.ButtonCOA.UseVisualStyleBackColor = False
        '
        'ButtonHome
        '
        Me.ButtonHome.BackColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(111, Byte), Integer))
        Me.ButtonHome.Cursor = System.Windows.Forms.Cursors.Hand
        Me.ButtonHome.Dock = System.Windows.Forms.DockStyle.Left
        Me.ButtonHome.FlatAppearance.BorderSize = 0
        Me.ButtonHome.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ButtonHome.Font = New System.Drawing.Font("Verdana Pro", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonHome.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.ButtonHome.Location = New System.Drawing.Point(0, 0)
        Me.ButtonHome.Name = "ButtonHome"
        Me.ButtonHome.Size = New System.Drawing.Size(67, 28)
        Me.ButtonHome.TabIndex = 14
        Me.ButtonHome.Text = "Home"
        Me.ButtonHome.UseVisualStyleBackColor = False
        '
        'ContextMenuStrip1
        '
        Me.ContextMenuStrip1.BackColor = System.Drawing.Color.FromArgb(CType(CType(77, Byte), Integer), CType(CType(96, Byte), Integer), CType(CType(130, Byte), Integer))
        Me.ContextMenuStrip1.DropShadowEnabled = False
        Me.ContextMenuStrip1.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ContextMenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.MainAccountToolStripMenuItem, Me.SubAccountToolStripMenuItem})
        Me.ContextMenuStrip1.Name = "ContextMenuStrip1"
        Me.ContextMenuStrip1.ShowImageMargin = False
        Me.ContextMenuStrip1.Size = New System.Drawing.Size(131, 48)
        '
        'MainAccountToolStripMenuItem
        '
        Me.MainAccountToolStripMenuItem.Name = "MainAccountToolStripMenuItem"
        Me.MainAccountToolStripMenuItem.Size = New System.Drawing.Size(130, 22)
        Me.MainAccountToolStripMenuItem.Text = "Main Account"
        '
        'SubAccountToolStripMenuItem
        '
        Me.SubAccountToolStripMenuItem.Name = "SubAccountToolStripMenuItem"
        Me.SubAccountToolStripMenuItem.Size = New System.Drawing.Size(130, 22)
        Me.SubAccountToolStripMenuItem.Text = "Sub Account"
        '
        'PanelMain
        '
        Me.PanelMain.BackColor = System.Drawing.SystemColors.Control
        Me.PanelMain.Controls.Add(Me.TextBoxSearch)
        Me.PanelMain.Controls.Add(Me.DataGridViewJoin)
        Me.PanelMain.Cursor = System.Windows.Forms.Cursors.Default
        Me.PanelMain.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PanelMain.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.PanelMain.Location = New System.Drawing.Point(0, 28)
        Me.PanelMain.Name = "PanelMain"
        Me.PanelMain.Size = New System.Drawing.Size(1184, 533)
        Me.PanelMain.TabIndex = 3
        '
        'TextBoxSearch
        '
        Me.TextBoxSearch.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextBoxSearch.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxSearch.Location = New System.Drawing.Point(896, 7)
        Me.TextBoxSearch.Name = "TextBoxSearch"
        Me.TextBoxSearch.Size = New System.Drawing.Size(276, 23)
        Me.TextBoxSearch.TabIndex = 19
        '
        'DataGridViewJoin
        '
        Me.DataGridViewJoin.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridViewJoin.Location = New System.Drawing.Point(0, 34)
        Me.DataGridViewJoin.Name = "DataGridViewJoin"
        Me.DataGridViewJoin.Size = New System.Drawing.Size(1184, 499)
        Me.DataGridViewJoin.TabIndex = 0
        '
        'COA
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.ClientSize = New System.Drawing.Size(1184, 561)
        Me.Controls.Add(Me.PanelMain)
        Me.Controls.Add(Me.PanelMenu)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Name = "COA"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.PanelMenu.ResumeLayout(False)
        Me.ContextMenuStrip1.ResumeLayout(False)
        Me.PanelMain.ResumeLayout(False)
        Me.PanelMain.PerformLayout()
        CType(Me.DataGridViewJoin, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents PanelMenu As System.Windows.Forms.Panel
    Friend WithEvents ButtonCOA As System.Windows.Forms.Button
    Friend WithEvents ContextMenuStrip1 As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents MainAccountToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SubAccountToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PanelMain As System.Windows.Forms.Panel
    Friend WithEvents DataGridViewJoin As System.Windows.Forms.DataGridView
    Friend WithEvents ButtonHome As System.Windows.Forms.Button
    Friend WithEvents TextBoxSearch As System.Windows.Forms.TextBox

End Class
