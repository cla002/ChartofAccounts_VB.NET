﻿Imports System.Data
Imports System.Data.SqlClient

Module Module1

    Public connect As New SqlConnection(("SERVER = laptop-01v541mn\sqlexpress; DATABASE = Chart_of_Accounts; INTEGRATED SECURITY = True"))
    Public command As New SqlCommand
    Public adapter As New SqlDataAdapter





End Module
