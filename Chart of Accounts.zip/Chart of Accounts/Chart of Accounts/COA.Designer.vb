﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class COA
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.PanelMenu = New System.Windows.Forms.Panel()
        Me.ButtonCOA = New System.Windows.Forms.Button()
        Me.ButtonHome = New System.Windows.Forms.Button()
        Me.PanelMain = New System.Windows.Forms.Panel()
        Me.TextBoxSearch = New System.Windows.Forms.TextBox()
        Me.DataGridViewJoin = New System.Windows.Forms.DataGridView()
        Me.ContextMenuStrip1 = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.MainAccountToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SubAccountToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PanelMenu.SuspendLayout()
        Me.PanelMain.SuspendLayout()
        CType(Me.DataGridViewJoin, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.ContextMenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'PanelMenu
        '
        Me.PanelMenu.BackColor = System.Drawing.SystemColors.Control
        Me.PanelMenu.Controls.Add(Me.ButtonCOA)
        Me.PanelMenu.Controls.Add(Me.ButtonHome)
        Me.PanelMenu.Dock = System.Windows.Forms.DockStyle.Top
        Me.PanelMenu.Location = New System.Drawing.Point(0, 0)
        Me.PanelMenu.Margin = New System.Windows.Forms.Padding(2)
        Me.PanelMenu.Name = "PanelMenu"
        Me.PanelMenu.Size = New System.Drawing.Size(1016, 32)
        Me.PanelMenu.TabIndex = 0
        '
        'ButtonCOA
        '
        Me.ButtonCOA.Cursor = System.Windows.Forms.Cursors.Hand
        Me.ButtonCOA.Dock = System.Windows.Forms.DockStyle.Left
        Me.ButtonCOA.FlatAppearance.BorderSize = 0
        Me.ButtonCOA.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ButtonCOA.Font = New System.Drawing.Font("Verdana", 9.5!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonCOA.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.ButtonCOA.Location = New System.Drawing.Point(95, 0)
        Me.ButtonCOA.Margin = New System.Windows.Forms.Padding(2)
        Me.ButtonCOA.Name = "ButtonCOA"
        Me.ButtonCOA.Size = New System.Drawing.Size(205, 32)
        Me.ButtonCOA.TabIndex = 1
        Me.ButtonCOA.Text = "Chart of Accounts"
        Me.ButtonCOA.UseVisualStyleBackColor = True
        '
        'ButtonHome
        '
        Me.ButtonHome.Cursor = System.Windows.Forms.Cursors.Hand
        Me.ButtonHome.Dock = System.Windows.Forms.DockStyle.Left
        Me.ButtonHome.FlatAppearance.BorderSize = 0
        Me.ButtonHome.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ButtonHome.Font = New System.Drawing.Font("Verdana", 9.5!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonHome.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.ButtonHome.Location = New System.Drawing.Point(0, 0)
        Me.ButtonHome.Margin = New System.Windows.Forms.Padding(2)
        Me.ButtonHome.Name = "ButtonHome"
        Me.ButtonHome.Size = New System.Drawing.Size(95, 32)
        Me.ButtonHome.TabIndex = 0
        Me.ButtonHome.Text = "Details"
        Me.ButtonHome.UseVisualStyleBackColor = True
        '
        'PanelMain
        '
        Me.PanelMain.BackColor = System.Drawing.Color.White
        Me.PanelMain.Controls.Add(Me.TextBoxSearch)
        Me.PanelMain.Controls.Add(Me.DataGridViewJoin)
        Me.PanelMain.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PanelMain.Location = New System.Drawing.Point(0, 32)
        Me.PanelMain.Margin = New System.Windows.Forms.Padding(2)
        Me.PanelMain.Name = "PanelMain"
        Me.PanelMain.Size = New System.Drawing.Size(1016, 509)
        Me.PanelMain.TabIndex = 1
        '
        'TextBoxSearch
        '
        Me.TextBoxSearch.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextBoxSearch.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxSearch.Location = New System.Drawing.Point(716, 5)
        Me.TextBoxSearch.Margin = New System.Windows.Forms.Padding(2)
        Me.TextBoxSearch.Name = "TextBoxSearch"
        Me.TextBoxSearch.Size = New System.Drawing.Size(289, 23)
        Me.TextBoxSearch.TabIndex = 1
        '
        'DataGridViewJoin
        '
        Me.DataGridViewJoin.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridViewJoin.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.DataGridViewJoin.Location = New System.Drawing.Point(0, 32)
        Me.DataGridViewJoin.Margin = New System.Windows.Forms.Padding(2)
        Me.DataGridViewJoin.Name = "DataGridViewJoin"
        Me.DataGridViewJoin.RowHeadersWidth = 51
        Me.DataGridViewJoin.RowTemplate.Height = 24
        Me.DataGridViewJoin.Size = New System.Drawing.Size(1016, 477)
        Me.DataGridViewJoin.TabIndex = 0
        '
        'ContextMenuStrip1
        '
        Me.ContextMenuStrip1.BackColor = System.Drawing.SystemColors.Control
        Me.ContextMenuStrip1.DropShadowEnabled = False
        Me.ContextMenuStrip1.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.ContextMenuStrip1.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.ContextMenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.MainAccountToolStripMenuItem, Me.SubAccountToolStripMenuItem})
        Me.ContextMenuStrip1.Name = "ContextMenuStrip1"
        Me.ContextMenuStrip1.ShowImageMargin = False
        Me.ContextMenuStrip1.Size = New System.Drawing.Size(139, 52)
        '
        'MainAccountToolStripMenuItem
        '
        Me.MainAccountToolStripMenuItem.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.MainAccountToolStripMenuItem.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.MainAccountToolStripMenuItem.Name = "MainAccountToolStripMenuItem"
        Me.MainAccountToolStripMenuItem.Size = New System.Drawing.Size(138, 24)
        Me.MainAccountToolStripMenuItem.Text = "Main Account"
        '
        'SubAccountToolStripMenuItem
        '
        Me.SubAccountToolStripMenuItem.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.SubAccountToolStripMenuItem.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.SubAccountToolStripMenuItem.Name = "SubAccountToolStripMenuItem"
        Me.SubAccountToolStripMenuItem.Size = New System.Drawing.Size(138, 24)
        Me.SubAccountToolStripMenuItem.Text = "Sub Account"
        '
        'COA
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1016, 541)
        Me.Controls.Add(Me.PanelMain)
        Me.Controls.Add(Me.PanelMenu)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.Margin = New System.Windows.Forms.Padding(2)
        Me.MaximizeBox = False
        Me.Name = "COA"
        Me.ShowIcon = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.PanelMenu.ResumeLayout(False)
        Me.PanelMain.ResumeLayout(False)
        Me.PanelMain.PerformLayout()
        CType(Me.DataGridViewJoin, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ContextMenuStrip1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents PanelMenu As Panel
    Friend WithEvents PanelMain As Panel
    Friend WithEvents DataGridViewJoin As DataGridView
    Friend WithEvents ButtonCOA As Button
    Friend WithEvents ButtonHome As Button
    Friend WithEvents TextBoxSearch As TextBox
    Friend WithEvents ContextMenuStrip1 As ContextMenuStrip
    Friend WithEvents MainAccountToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SubAccountToolStripMenuItem As ToolStripMenuItem
End Class
