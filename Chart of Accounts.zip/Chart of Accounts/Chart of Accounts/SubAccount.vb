﻿Imports System.Data
Imports System.Data.SqlClient

Public Class SubAccount

    Private Sub SubAccount_Load(ByVal sender As Object, ByVal e As EventArgs) Handles MyBase.Load
        ComboLoadCode()
        
        emptyFields()
        'DATAGRID
        subAccLoad()
        datagridDesign()

        ButtonDelete.Visible = False
        ButtonEdit.Visible = False

        ComboBoxCode.Enabled = True
        TextBoxMainName.Enabled = True
        TextBoxSubCode.Enabled = False

        TextBoxSubSearch.Focus()

    End Sub

    ''' <summary>
    ''' FILL COMBOBOX WITH ACCOUNT_CODES FROM MAIN ACCOUNT
    ''' </summary>
    ''' <remarks></remarks>
    Sub ComboLoadCode()
        Try

            Dim AccCode As New DataTable

            adapter = New SqlDataAdapter("SELECT * FROM Main_Account ORDER BY Account_Code", connect)
            adapter.Fill(AccCode)

            ComboBoxCode.DataSource = AccCode
            ComboBoxCode.DisplayMember = "Account_Code"
            ComboBoxCode.ValueMember = "Account_Code"


        Catch ex As Exception
            MsgBox(ex.Message)
        End Try


    End Sub


    ''' <summary>
    ''' TEXTBOX LOAD
    ''' </summary>
    ''' <remarks></remarks>
    Sub CodeLoadName()

        Try

            Command = New SqlCommand

            Command.Parameters.Add("Account_Code", SqlDbType.VarChar).Value = ComboBoxCode.Text

            adapter = New SqlDataAdapter("SELECT Account_Name FROM Main_Account WHERE Account_Code LIKE '" & ComboBoxCode.Text & "'", connect)


            Dim CodeTbl As New DataTable
            adapter.Fill(CodeTbl)

            If CodeTbl.Rows.Count > 0 Then
                TextBoxMainName.Text = CodeTbl.Rows(0)(0).ToString
                ComboBoxCode.Enabled = False
                TextBoxMainName.Enabled = False

            End If

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub

    Sub labelSubTypeLoad()
        Try

            Command = New SqlCommand
            Command.Parameters.Add("Sub_Type", SqlDbType.VarChar).Value = ComboBoxCode.Text

            adapter = New SqlDataAdapter("SELECT Sub_Type FROM Main_Account WHERE Account_Code LIKE '" & ComboBoxCode.Text & "'", connect)

            Dim table As New DataTable
            adapter.Fill(table)

            If table.Rows.Count > 0 Then
                LabelSubType.Text = "(" & table.Rows(0)(0).ToString & ")"
                LabelSubType.Enabled = False
                ComboBoxCode.Enabled = False
                TextBoxMainName.Enabled = False

            End If

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub


#Region "DATAGRID DESIGN"

    Sub datagridDesign()

        DataGridViewSub.ColumnHeadersDefaultCellStyle.Font = New Font("Arial", 9, FontStyle.Bold)

        DataGridViewSub.BackgroundColor = Color.White
        DataGridViewSub.DefaultCellStyle.SelectionBackColor = Color.Yellow
        DataGridViewSub.DefaultCellStyle.SelectionForeColor = Color.Black
        DataGridViewSub.SelectionMode = DataGridViewSelectionMode.FullRowSelect

        DataGridViewSub.DefaultCellStyle.WrapMode = DataGridViewTriState.False

        DataGridViewSub.AllowUserToResizeColumns = True
        DataGridViewSub.AllowUserToAddRows = False
        DataGridViewSub.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill

    End Sub

#End Region

    Private Sub ComboBoxCode_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles ComboBoxCode.SelectedIndexChanged

        CodeLoadName()
        TextBoxSubAccName.Focus()
        labelSubTypeLoad()
     
    End Sub


#Region "EMPTY FIELDS"

    Sub emptyFields()
        ComboBoxCode.Text = "--Account Code--"
        TextBoxMainName.Text = ""
        TextBoxSubCode.Text = "--Auto Generated--"
        TextBoxSubAccName.Text = ""
        LabelSubType.Text = ""

    End Sub

#End Region

    Private Sub ButtonSave_Click(ByVal sender As Object, ByVal e As EventArgs) Handles ButtonSave.Click
        Try

            Command = New SqlCommand("INSERT INTO Sub_Account(Main_Code, Main_AC_Name, Sub_AC_Name) VALUES(@Main_Code, @Main_AC_Name, @Sub_AC_Name)", connect)

            Command.Parameters.AddWithValue("Main_Code", ComboBoxCode.Text)
            command.Parameters.AddWithValue("Main_AC_Name", TextBoxMainName.Text)
            Command.Parameters.AddWithValue("Sub_AC_Name", TextBoxSubAccName.Text)

            If ComboBoxCode.Text = "--Account Code--" Or TextBoxSubAccName.Text = "" Then
                MessageBox.Show("Required Field should not be empty", "Main Account", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            Else

                connect.Open()
                command.ExecuteNonQuery()
                connect.Close()

                ComboBoxCode.Enabled = True
                TextBoxMainName.Enabled = True

                emptyFields()

                subAccLoad()
                MessageBox.Show("Sub Account Added Successfully!", "Main Account", MessageBoxButtons.OK, MessageBoxIcon.Information)

            End If

        Catch ex As Exception
            MessageBox.Show("Check for duplicate values!", "Sub Account", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            'MsgBox(ex.Message)
            connect.Close()
        End Try

        CodeLoadName()


    End Sub

    ''' <summary>
    ''' DATAGRID VIEW
    ''' </summary>
    ''' <remarks></remarks>
    Sub subAccLoad()
        Try


            adapter = New SqlDataAdapter("SELECT Main_Code, Main_AC_Name, Sub_Code, Sub_AC_Name FROM Sub_Account ORDER BY Main_Code", connect)

            Dim subTbl As New DataTable
            adapter.Fill(subTbl)

            DataGridViewSub.DataSource = subTbl


        Catch ex As Exception
            MsgBox(ex.Message)
        End Try


    End Sub

    Private Sub ButtonClear_Click(ByVal sender As Object, ByVal e As EventArgs) Handles ButtonClear.Click
        emptyFields()

        ButtonDelete.Visible = False
        ButtonEdit.Visible = False
        ButtonSave.Visible = True
        ComboBoxCode.Enabled = True
        TextBoxMainName.Enabled = True

    End Sub

    Private Sub ButtonSearch_Click(ByVal sender As Object, ByVal e As EventArgs) Handles ButtonSearch.Click

        If TextBoxSubSearch.Text = "" Then
            MessageBox.Show("No Input", "Main Account", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            Exit Sub
        End If



        Command = New SqlCommand("SELECT Main_Code, Main_AC_Name, Sub_Code, Sub_AC_Name FROM Sub_Account WHERE Main_Code LIKE '" & TextBoxSubSearch.Text & "' or Main_AC_Name LIKE '" & TextBoxSubSearch.Text & "' or Sub_Code LIKE '" & TextBoxSubSearch.Text & "' or Sub_AC_Name LIKE '" & TextBoxSubSearch.Text & "' ORDER BY Main_Code", connect)

        Command.Parameters.Add("Main_Code", SqlDbType.VarChar).Value = TextBoxSubSearch.Text
        Command.Parameters.Add("Sub_Code", SqlDbType.VarChar).Value = TextBoxSubSearch.Text
        Command.Parameters.Add("Main_AC_Name", SqlDbType.VarChar).Value = TextBoxSubSearch.Text
        Command.Parameters.Add("Sub_AC_Name", SqlDbType.VarChar).Value = TextBoxSubSearch.Text

        Try

            adapter = New SqlDataAdapter(Command)
            Dim SubSearch As New DataTable
            adapter.Fill(SubSearch)

            If SubSearch.Rows.Count > 0 Then
                ComboBoxCode.Text = SubSearch.Rows(0)(0).ToString()
                TextBoxMainName.Text = SubSearch.Rows(0)(1).ToString()
                TextBoxSubCode.Text = SubSearch.Rows(0)(2).ToString()
                TextBoxSubAccName.Text = SubSearch.Rows(0)(3).ToString()

                ComboBoxCode.Enabled = False
                TextBoxMainName.Enabled = False
                TextBoxSubSearch.Text = ""
                ButtonSave.Visible = False
                ButtonEdit.Visible = True
                ButtonDelete.Visible = True


            End If



        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try


    End Sub

    Private Sub TextBoxSearch_TextChanged(ByVal sender As Object, ByVal e As EventArgs) Handles TextBoxSubSearch.TextChanged
        Dim SubSearch As New DataTable

        adapter = New SqlDataAdapter("SELECT Main_Code, Main_AC_Name, Sub_Code, Sub_AC_Name FROM Sub_Account WHERE Main_Code LIKE '%" & TextBoxSubSearch.Text & "%' or Main_AC_Name LIKE '%" & TextBoxSubSearch.Text & "%' or Sub_Code LIKE '%" & TextBoxSubSearch.Text & "%' or Sub_AC_Name LIKE '%" & TextBoxSubSearch.Text & "%' ORDER BY Main_Code", connect)
        adapter.Fill(SubSearch)

        DataGridViewSub.DataSource = SubSearch

    End Sub

    Private Sub DataGridViewSub_CellClick(ByVal sender As Object, ByVal e As DataGridViewCellEventArgs) Handles DataGridViewSub.CellClick
        Try

            ComboBoxCode.text = DataGridViewSub.Rows(e.RowIndex).Cells(0).Value.ToString
            TextBoxMainName.Text = DataGridViewSub.Rows(e.RowIndex).Cells(1).Value.ToString
            TextBoxSubCode.Text = DataGridViewSub.Rows(e.RowIndex).Cells(2).Value.ToString
            TextBoxSubAccName.Text = DataGridViewSub.Rows(e.RowIndex).Cells(3).Value.ToString

            ComboBoxCode.Enabled = False
            TextBoxMainName.Enabled = False
            TextBoxSubSearch.Text = ""
            ButtonSave.Visible = False
            ButtonDelete.Visible = True
            ButtonEdit.Visible = True

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub


    Private Sub ButtonEdit_Click(ByVal sender As Object, ByVal e As EventArgs) Handles ButtonEdit.Click
        Try

            Command = New SqlCommand("UPDATE Sub_Account SET Sub_AC_Name = @Sub_AC_Name WHERE Sub_Code LIKE '" & TextBoxSubCode.Text & "'", connect)

            Command.Parameters.AddWithValue("Sub_AC_Name", TextBoxSubAccName.Text)

            If TextBoxSubAccName.Text = "" Then
                MessageBox.Show("Required Field should not be empty", "Main Account", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

            Else
                connect.Open()
                Command.ExecuteNonQuery()
                connect.Close()

                emptyFields()

                subAccLoad()
                MessageBox.Show("Account Updated Successfully!", "Main Account", MessageBoxButtons.OK, MessageBoxIcon.Information)

                ButtonSave.Visible = True
                ButtonClear.Visible = True
                ButtonEdit.Visible = False
                ButtonDelete.Visible = False

                ComboBoxCode.Enabled = True
                TextBoxMainName.Enabled = True

            End If

        Catch ex As Exception
            MessageBox.Show("Check for duplicate values!", "Sub Account", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

        End Try


    End Sub

    Private Sub ButtonDelete_Click(ByVal sender As Object, ByVal e As EventArgs) Handles ButtonDelete.Click
        Command = New SqlCommand("DELETE FROM Sub_Account WHERE Sub_Code LIKE '" & TextBoxSubCode.Text & "'", connect)

        Dim subDelete As DialogResult
        subDelete = MessageBox.Show("Delete Sub Account?", "Sub Account", MessageBoxButtons.YesNo, MessageBoxIcon.Question)

        If subDelete = Windows.Forms.DialogResult.Yes Then

            connect.Open()
            Command.ExecuteNonQuery()
            connect.Close()

        Else
            Return

        End If

        emptyFields()

        ComboBoxCode.Enabled = True
        TextBoxMainName.Enabled = True
        ButtonSave.Visible = True
        ButtonEdit.Visible = False
        ButtonDelete.Visible = False

        subAccLoad()

        MessageBox.Show("Sub Account Successfully Deleted!", "Sub Account", MessageBoxButtons.OK, MessageBoxIcon.Information)

    End Sub

    Private Sub TextBoxSubCode_KeyPress(ByVal sender As Object, ByVal e As KeyPressEventArgs) Handles TextBoxSubCode.KeyPress
        If e.KeyChar = ControlChars.Cr Then
            e.Handled = True
            TextBoxSubAccName.Focus()

        End If
    End Sub


    Private Sub DataGridViewSub_ColumnAdded(ByVal sender As Object, ByVal e As DataGridViewColumnEventArgs) Handles DataGridViewSub.ColumnAdded
        e.Column.SortMode = DataGridViewColumnSortMode.NotSortable
    End Sub


    Private Sub TextBoxSubAccName_KeyPress(ByVal sender As Object, ByVal e As KeyPressEventArgs) Handles TextBoxSubAccName.KeyPress
        Try

            If e.KeyChar = Chr(13) Then
                MsgBox("Click Clear or Save")
                e.Handled = True

            End If

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub TextBoxSubSearch_KeyPress(ByVal sender As Object, ByVal e As KeyPressEventArgs) Handles TextBoxSubSearch.KeyPress
        If e.KeyChar = Chr(13) Then
            ButtonSearch_Click(Me, EventArgs.Empty)

            e.Handled = True

            TextBoxSubSearch.Focus()

        End If
    End Sub

    Private Sub DataGridViewSub_KeyPress(ByVal sender As Object, ByVal e As KeyPressEventArgs) Handles DataGridViewSub.KeyPress
        If e.KeyChar = Chr(13) Then
            ButtonSearch_Click(Me, EventArgs.Empty)

            e.Handled = True

            TextBoxSubSearch.Focus()


        End If
    End Sub

End Class