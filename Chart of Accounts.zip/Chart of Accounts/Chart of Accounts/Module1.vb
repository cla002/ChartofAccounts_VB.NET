﻿Imports System.Data
Imports System.Data.SqlClient

Module Module1

    'Public connect As New SqlConnection("SERVER = LAPTOP-CJV15I1C\SQLEXPRESS; DATABASE = Chart_of_Accounts; INTEGRATED SECURITY = TRUE")
    Public connect As New SqlConnection("SERVER = LAPTOP-01V541MN\SQLEXPRESS; DATABASE = Chart_of_Accounts; INTEGRATED SECURITY = TRUE")
    Public command As New SqlCommand
    Public adapter As New SqlDataAdapter


End Module
