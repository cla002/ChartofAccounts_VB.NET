﻿Imports System.Data
Imports System.Data.SqlClient

Public Class MainAccount

    Private Sub MainAccount_Load(ByVal sender As Object, ByVal e As EventArgs) Handles MyBase.Load

        MainLoad()
        datagridDesign()

        ButtonEdit.Visible = False
        ButtonDelete.Visible = False
        TextBoxAccName.Focus()

        ComboType()

        emptyField()


    End Sub


    Sub ComboType()
        ComboBoxType.Items.Add("Assets")
        ComboBoxType.Items.Add("Liabilities")
        ComboBoxType.Items.Add("Equity")
        ComboBoxType.Items.Add("Revenues")
        ComboBoxType.Items.Add("Expenses")
        ComboBoxType.Items.Add("Other")


    End Sub

    ''' <summary>
    ''' DATAGRID VIEW
    ''' </summary>
    ''' <remarks></remarks>
    Sub MainLoad()
        Try

            Command = New SqlCommand("SELECT * FROM Main_Account ORDER BY Account_Code", connect)
            Dim mainTable As New DataTable


            adapter = New SqlDataAdapter(Command)
            adapter.Fill(mainTable)

            DataGridViewMain.DataSource = mainTable

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub

#Region "DATAGRID DESIGN"
    Sub datagridDesign()
        DataGridViewMain.ColumnHeadersDefaultCellStyle.Font = New Font("Arial", 9, FontStyle.Bold)

        DataGridViewMain.BackgroundColor = Color.White
        DataGridViewMain.DefaultCellStyle.SelectionBackColor = Color.Yellow
        DataGridViewMain.DefaultCellStyle.SelectionForeColor = Color.Black
        DataGridViewMain.SelectionMode = DataGridViewSelectionMode.FullRowSelect

        DataGridViewMain.DefaultCellStyle.WrapMode = DataGridViewTriState.False

        DataGridViewMain.AllowUserToResizeColumns = True
        DataGridViewMain.AllowUserToAddRows = False
        DataGridViewMain.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill

    End Sub
#End Region


    Private Sub TextBoxAccName_KeyPress(ByVal sender As Object, ByVal e As KeyPressEventArgs) Handles TextBoxAccName.KeyPress
        If e.KeyChar = ControlChars.Cr Then
            e.Handled = True
            TextBoxCode.Focus()

        End If
    End Sub

    Private Sub TextBoxCode_KeyPress(ByVal sender As Object, ByVal e As KeyPressEventArgs) Handles TextBoxCode.KeyPress
        If e.KeyChar = ControlChars.Cr Then
            e.Handled = True
            TextBoxSubType.Focus()

        End If
    End Sub


    Private Sub ButtonSave_Click(ByVal sender As Object, ByVal e As EventArgs) Handles ButtonSave.Click
        Try

            command = New SqlCommand("INSERT INTO Main_Account(Account_Code, Account_Name, Type, Sub_Type) VALUES(@Account_Code, @Account_Name, @Type, @Sub_Type)", connect)

            command.Parameters.AddWithValue("Account_Name", TextBoxAccName.Text)
            command.Parameters.AddWithValue("Account_Code", TextBoxCode.Text)
            command.Parameters.AddWithValue("Type", ComboBoxType.Text)
            command.Parameters.AddWithValue("Sub_Type", TextBoxSubType.Text)

            If TextBoxAccName.Text = "" Or TextBoxCode.Text = "" Or ComboBoxType.Text = "--Select--" Then
                MessageBox.Show("Required Field should not be empty", "Main Account", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

            ElseIf Not IsNumeric(TextBoxCode.Text) Then
                MessageBox.Show("Code Should be a number!", "Main Account", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                TextBoxCode.Clear()
                TextBoxCode.Focus()

            Else

                connect.Open()
                command.ExecuteNonQuery()
                connect.Close()

                emptyField()

                MainLoad()

                MessageBox.Show("Account Added Successfully!", "Main Account", MessageBoxButtons.OK, MessageBoxIcon.Information)

            End If

        Catch ex As Exception
            MessageBox.Show("Check for duplicate values!", "Sub Account", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            connect.Close()

        End Try

        TextBoxAccName.Focus()
        TextBoxCode.Enabled = True

    End Sub


    Private Sub ButtonSearch_Click(ByVal sender As Object, ByVal e As EventArgs) Handles ButtonSearch.Click
        If TextBoxSearch.Text = "" Then
            MessageBox.Show("No Input", "Main Account", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)


        End If

        command = New SqlCommand("SELECT * FROM Main_Account WHERE Account_Code Like '" & TextBoxSearch.Text & "' or Account_Name LIKE '" & TextBoxSearch.Text & "' or Type LIKE '" & TextBoxSearch.Text & "' or Sub_Type LIKE '" & TextBoxSearch.Text & "' ORDER BY Account_Code", connect)

        command.Parameters.Add("Account_Code", SqlDbType.VarChar).Value = TextBoxSearch.Text
        command.Parameters.Add("Account_Name", SqlDbType.VarChar).Value = TextBoxSearch.Text
        command.Parameters.Add("Type", SqlDbType.VarChar).Value = TextBoxSearch.Text
        command.Parameters.Add("Sub_Type", SqlDbType.VarChar).Value = TextBoxSearch.Text
        Try

            adapter = New SqlDataAdapter(command)
            Dim MainSearch As New DataTable
            adapter.Fill(MainSearch)

            If MainSearch.Rows.Count > 0 Then
                TextBoxCode.Text = MainSearch.Rows(0)(0).ToString
                TextBoxAccName.Text = MainSearch.Rows(0)(1).ToString
                ComboBoxType.Text = MainSearch.Rows(0)(2).ToString
                TextBoxSubType.Text = MainSearch.Rows(0)(3).ToString

                PanelMainForm.Visible = True

                TextBoxSearch.Focus()

                TextBoxSearch.Text = ""
                ButtonSave.Visible = False
                ButtonEdit.Visible = True
                ButtonDelete.Visible = True

                TextBoxCode.Enabled = False


            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message)

        End Try


    End Sub

    Private Sub TextBoxSearch_TextChanged(ByVal sender As Object, ByVal e As EventArgs) Handles TextBoxSearch.TextChanged
        Dim searchTbl As New DataTable
        adapter = New SqlDataAdapter("SELECT * FROM Main_Account WHERE Account_Code Like '%" & TextBoxSearch.Text & "%' or Account_Name LIKE '%" & TextBoxSearch.Text & "%' or Type LIKE '%" & TextBoxSearch.Text & "%' or Sub_Type LIKE '%" & TextBoxSearch.Text & "%' ORDER BY Account_Code", connect)
        adapter.Fill(searchTbl)

        DataGridViewMain.DataSource = searchTbl

    End Sub

    Private Sub ButtonClear_Click(ByVal sender As Object, ByVal e As EventArgs) Handles ButtonClear.Click

        emptyField()

        ButtonEdit.Visible = False
        ButtonDelete.Visible = False
        ButtonSave.Visible = True

        TextBoxAccName.Focus()
        TextBoxCode.Enabled = True

    End Sub

    Private Sub DataGridViewMain_CellClick(ByVal sender As Object, ByVal e As DataGridViewCellEventArgs) Handles DataGridViewMain.CellClick
        Try

            TextBoxCode.Text = DataGridViewMain.Rows(e.RowIndex).Cells(0).Value.ToString
            TextBoxAccName.Text = DataGridViewMain.Rows(e.RowIndex).Cells(1).Value.ToString
            ComboBoxType.Text = DataGridViewMain.Rows(e.RowIndex).Cells(2).Value.ToString
            TextBoxSubType.Text = DataGridViewMain.Rows(e.RowIndex).Cells(3).Value.ToString

            PanelMainForm.Visible = True

            TextBoxSearch.Text = ""
            ButtonSave.Visible = False
            ButtonEdit.Visible = True
            ButtonDelete.Visible = True

            TextBoxCode.Enabled = False

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try

    End Sub

    Private Sub ButtonEdit_Click(ByVal sender As Object, ByVal e As EventArgs) Handles ButtonEdit.Click
        Try

            command = New SqlCommand("UPDATE Main_Account SET Account_Name = @Account_Name, Account_Code = @Account_Code, Type = @Type, Sub_Type = @Sub_Type WHERE Account_Code Like '" & TextBoxCode.Text & "'", connect)

            command.Parameters.AddWithValue("Account_Name", TextBoxAccName.Text)
            command.Parameters.AddWithValue("Account_Code", TextBoxCode.Text)
            command.Parameters.AddWithValue("Type", ComboBoxType.Text)
            command.Parameters.AddWithValue("Sub_Type", TextBoxSubType.Text)

            If TextBoxAccName.Text = "" Or TextBoxCode.Text = "" Or ComboBoxType.Text = "" Then
                MessageBox.Show("Required Field should not be empty", "Main Account", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

            Else

                connect.Open()
                command.ExecuteNonQuery()
                connect.Close()

                emptyField()

                MainLoad()
                MessageBox.Show("Account Updated Successfully!", "Main Account", MessageBoxButtons.OK, MessageBoxIcon.Information)

                ButtonSave.Visible = True
                ButtonClear.Visible = True
                ButtonEdit.Visible = False
                ButtonDelete.Visible = False

                TextBoxAccName.Focus()
                TextBoxCode.Enabled = True

            End If
        Catch ex As Exception
            MessageBox.Show("Check for duplicate values!", "Sub Account", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            connect.Close()

        End Try



    End Sub

    Private Sub ButtonDelete_Click(ByVal sender As Object, ByVal e As EventArgs) Handles ButtonDelete.Click
        command = New SqlCommand("DELETE FROM Main_Account WHERE Account_Code LIKE '" & TextBoxCode.Text & "'", connect)

        Dim AccDelete As DialogResult
        AccDelete = MessageBox.Show("Delete Account?", "Main Account", MessageBoxButtons.YesNo, MessageBoxIcon.Question)

        If AccDelete = Windows.Forms.DialogResult.Yes Then
            connect.Open()
            command.ExecuteNonQuery()
            connect.Close()

            emptyField()

        Else
            Return

        End If


        ButtonSave.Visible = True
        ButtonClear.Visible = True
        ButtonEdit.Visible = False
        ButtonDelete.Visible = False

        MainLoad()

        MessageBox.Show("Account Successfully Deleted!", "Main Account", MessageBoxButtons.OK, MessageBoxIcon.Information)

        TextBoxAccName.Focus()
        TextBoxCode.Enabled = True

    End Sub

    ''' <summary>
    ''' CLEAR FIELDS
    ''' </summary>
    ''' <remarks></remarks>
#Region "EMPTY FIELDS"
    Sub emptyField()

        TextBoxCode.Text = ""
        TextBoxAccName.Text = ""
        ComboBoxType.Text = "--Select--"
        TextBoxSubType.Text = ""

    End Sub
#End Region

    Private Sub TextBoxCode_LostFocus(ByVal sender As Object, ByVal e As EventArgs) Handles TextBoxCode.LostFocus
        Dim dset As New DataSet

        If TextBoxCode.Text <> "" Then
            adapter = New SqlDataAdapter("SELECT * FROM Main_Account WHERE Account_Code LIKE '" & TextBoxCode.Text & "'", connect)
            dset = New DataSet
            adapter.Fill(dset, "Main_Account")

            If dset.Tables("Main_Account").Rows.Count > 0 Then
                TextBoxCode.Clear()
                TextBoxCode.Focus()

            End If

        Else
            TextBoxCode.Focus()

        End If

    End Sub


    Private Sub ComboBoxType_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles ComboBoxType.SelectedIndexChanged

        TextBoxSubType.Focus()

    End Sub


    Private Sub DataGridViewMain_ColumnAdded(ByVal sender As Object, ByVal e As DataGridViewColumnEventArgs) Handles DataGridViewMain.ColumnAdded
        e.Column.SortMode = DataGridViewColumnSortMode.NotSortable
    End Sub


    Private Sub TextBoxSubType_KeyPress(ByVal sender As Object, ByVal e As KeyPressEventArgs) Handles TextBoxSubType.KeyPress
        If e.KeyChar = Chr(13) Then
            ButtonSave_Click(Me, EventArgs.Empty)

            e.Handled = True

        End If
    End Sub

    Private Sub TextBoxSearch_KeyPress(ByVal sender As Object, ByVal e As KeyPressEventArgs) Handles TextBoxSearch.KeyPress
        If e.KeyChar = Chr(13) Then
            ButtonSearch_Click(Me, EventArgs.Empty)

            e.Handled = True

            TextBoxSearch.Focus()

            PanelMainForm.Visible = True
        End If
    End Sub

    Private Sub DataGridViewMain_KeyPress(ByVal sender As Object, ByVal e As KeyPressEventArgs) Handles DataGridViewMain.KeyPress
        If e.KeyChar = Chr(13) Then
            ButtonSearch_Click(Me, EventArgs.Empty)

            e.Handled = True

            TextBoxSearch.Focus()

            PanelMainForm.Visible = True

        End If
    End Sub

End Class