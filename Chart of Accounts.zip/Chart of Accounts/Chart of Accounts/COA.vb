﻿Imports System.Data.SqlClient

Public Class COA

    Dim MA As New MainAccount
    Dim SA As New SubAccount

    'Drop down
    Private Sub ButtonCOA_Click(ByVal sender As Object, ByVal e As EventArgs) Handles ButtonCOA.Click
        ContextMenuStrip1.Show(ButtonCOA, 0, ButtonCOA.Height)

        ContextMenuStrip1.ForeColor = Color.White


    End Sub

    Sub GridLoad()
        Try

            adapter = New SqlDataAdapter("SELECT MA.Account_Code, SA.Sub_Code, MA.Account_Name, SA.Sub_AC_Name, MA.Type, MA.Sub_Type FROM Main_Account MA LEFT JOIN Sub_Account SA ON MA.Account_Code = SA.Main_Code ORDER BY Account_Code", connect)

            Dim dTable As New DataTable
            adapter.Fill(dTable)

            DataGridViewJoin.DataSource = dTable

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub

    Sub DatagridDesign()

        DataGridViewJoin.ColumnHeadersDefaultCellStyle.Font = New Font("Arial", 9, FontStyle.Bold)

        DataGridViewJoin.BackgroundColor = Color.White
        DataGridViewJoin.DefaultCellStyle.SelectionBackColor = Color.Yellow
        DataGridViewJoin.DefaultCellStyle.SelectionForeColor = Color.Black
        DataGridViewJoin.SelectionMode = DataGridViewSelectionMode.FullRowSelect

        DataGridViewJoin.DefaultCellStyle.WrapMode = DataGridViewTriState.False

        DataGridViewJoin.AllowUserToResizeColumns = True
        DataGridViewJoin.AllowUserToAddRows = False
        DataGridViewJoin.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill

    End Sub

    Private Sub COA_Load(ByVal sender As Object, ByVal e As EventArgs) Handles MyBase.Load

        DatagridDesign()
        GridLoad()

    End Sub

    Private Sub ButtonHome_Click(ByVal sender As Object, ByVal e As EventArgs) Handles ButtonHome.Click
        MA.Dispose()
        SA.Dispose()
        DataGridViewJoin.Visible = True

        GridLoad()
    End Sub


    Private Sub TextBoxSearch_TextChanged(ByVal sender As Object, ByVal e As EventArgs) Handles TextBoxSearch.TextChanged
        Dim getSearch As New DataTable

        adapter = New SqlDataAdapter("SELECT MA.Account_Code, SA.Sub_Code, MA.Account_Name, SA.Sub_AC_Name, MA.Type, MA.Sub_Type FROM Main_Account MA LEFT JOIN Sub_Account SA ON MA.Account_Code = SA.Main_Code WHERE MA.Account_Code LIKE '%" & TextBoxSearch.Text & "%' or Sub_Code LIKE '%" & TextBoxSearch.Text & "%' or Account_Name LIKE '%" & TextBoxSearch.Text & "%' or Sub_AC_Name LIKE '%" & TextBoxSearch.Text & "%' or Type LIKE '%" & TextBoxSearch.Text & "%' or Sub_Type LIKE '%" & TextBoxSearch.Text & "%' ORDER BY Account_Code", connect)

        adapter.Fill(getSearch)

        DataGridViewJoin.DataSource = getSearch

    End Sub

    Private Sub DataGridViewJoin_ColumnAdded(ByVal sender As Object, ByVal e As DataGridViewColumnEventArgs) Handles DataGridViewJoin.ColumnAdded
        e.Column.SortMode = DataGridViewColumnSortMode.NotSortable
    End Sub

    Private Sub MainAccountToolStripMenuItem_Click_1(ByVal sender As Object, ByVal e As EventArgs) Handles MainAccountToolStripMenuItem.Click
        With MA
            .TopLevel = False
            PanelMain.Controls.Add(MA)
            .BringToFront()
            .Show()

            'SA.Dispose()
            DataGridViewJoin.Visible = False

        End With
    End Sub

    Private Sub SubAccountToolStripMenuItem_Click_1(ByVal sender As Object, ByVal e As EventArgs) Handles SubAccountToolStripMenuItem.Click
        With SA
            .TopLevel = False
            PanelMain.Controls.Add(SA)
            .BringToFront()
            .Show()

            'MA.Dispose()
            DataGridViewJoin.Visible = False

        End With
    End Sub

End Class










