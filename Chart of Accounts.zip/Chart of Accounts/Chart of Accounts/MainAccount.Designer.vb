﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class MainAccount
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.TextBoxSearch = New System.Windows.Forms.TextBox()
        Me.PanelMainGrid = New System.Windows.Forms.Panel()
        Me.ButtonSearch = New System.Windows.Forms.Button()
        Me.DataGridViewMain = New System.Windows.Forms.DataGridView()
        Me.PanelMainForm = New System.Windows.Forms.Panel()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.ButtonDelete = New System.Windows.Forms.Button()
        Me.ButtonEdit = New System.Windows.Forms.Button()
        Me.ButtonSave = New System.Windows.Forms.Button()
        Me.ButtonClear = New System.Windows.Forms.Button()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.ComboBoxType = New System.Windows.Forms.ComboBox()
        Me.TextBoxSubType = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.TextBoxCode = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.TextBoxAccName = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.PanelMainGrid.SuspendLayout()
        CType(Me.DataGridViewMain, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PanelMainForm.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'TextBoxSearch
        '
        Me.TextBoxSearch.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextBoxSearch.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxSearch.Location = New System.Drawing.Point(458, 4)
        Me.TextBoxSearch.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.TextBoxSearch.Name = "TextBoxSearch"
        Me.TextBoxSearch.Size = New System.Drawing.Size(184, 23)
        Me.TextBoxSearch.TabIndex = 3
        '
        'PanelMainGrid
        '
        Me.PanelMainGrid.BackColor = System.Drawing.Color.White
        Me.PanelMainGrid.Controls.Add(Me.ButtonSearch)
        Me.PanelMainGrid.Controls.Add(Me.DataGridViewMain)
        Me.PanelMainGrid.Controls.Add(Me.TextBoxSearch)
        Me.PanelMainGrid.Dock = System.Windows.Forms.DockStyle.Left
        Me.PanelMainGrid.Location = New System.Drawing.Point(0, 0)
        Me.PanelMainGrid.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.PanelMainGrid.Name = "PanelMainGrid"
        Me.PanelMainGrid.Size = New System.Drawing.Size(724, 543)
        Me.PanelMainGrid.TabIndex = 1
        '
        'ButtonSearch
        '
        Me.ButtonSearch.BackColor = System.Drawing.Color.White
        Me.ButtonSearch.Cursor = System.Windows.Forms.Cursors.Hand
        Me.ButtonSearch.FlatAppearance.BorderSize = 0
        Me.ButtonSearch.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ButtonSearch.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonSearch.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.ButtonSearch.Location = New System.Drawing.Point(646, 2)
        Me.ButtonSearch.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.ButtonSearch.Name = "ButtonSearch"
        Me.ButtonSearch.Size = New System.Drawing.Size(80, 25)
        Me.ButtonSearch.TabIndex = 5
        Me.ButtonSearch.Text = "Search"
        Me.ButtonSearch.UseVisualStyleBackColor = False
        '
        'DataGridViewMain
        '
        Me.DataGridViewMain.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridViewMain.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.DataGridViewMain.Location = New System.Drawing.Point(0, 30)
        Me.DataGridViewMain.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.DataGridViewMain.Name = "DataGridViewMain"
        Me.DataGridViewMain.RowHeadersWidth = 51
        Me.DataGridViewMain.RowTemplate.Height = 24
        Me.DataGridViewMain.Size = New System.Drawing.Size(724, 513)
        Me.DataGridViewMain.TabIndex = 1
        '
        'PanelMainForm
        '
        Me.PanelMainForm.Controls.Add(Me.Panel1)
        Me.PanelMainForm.Controls.Add(Me.Label9)
        Me.PanelMainForm.Controls.Add(Me.Label8)
        Me.PanelMainForm.Controls.Add(Me.Label7)
        Me.PanelMainForm.Controls.Add(Me.Label6)
        Me.PanelMainForm.Controls.Add(Me.ComboBoxType)
        Me.PanelMainForm.Controls.Add(Me.TextBoxSubType)
        Me.PanelMainForm.Controls.Add(Me.Label5)
        Me.PanelMainForm.Controls.Add(Me.Label4)
        Me.PanelMainForm.Controls.Add(Me.TextBoxCode)
        Me.PanelMainForm.Controls.Add(Me.Label3)
        Me.PanelMainForm.Controls.Add(Me.TextBoxAccName)
        Me.PanelMainForm.Controls.Add(Me.Label2)
        Me.PanelMainForm.Controls.Add(Me.Label1)
        Me.PanelMainForm.Dock = System.Windows.Forms.DockStyle.Right
        Me.PanelMainForm.Location = New System.Drawing.Point(728, 0)
        Me.PanelMainForm.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.PanelMainForm.Name = "PanelMainForm"
        Me.PanelMainForm.Size = New System.Drawing.Size(300, 543)
        Me.PanelMainForm.TabIndex = 3
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.ButtonDelete)
        Me.Panel1.Controls.Add(Me.ButtonEdit)
        Me.Panel1.Controls.Add(Me.ButtonSave)
        Me.Panel1.Controls.Add(Me.ButtonClear)
        Me.Panel1.Location = New System.Drawing.Point(11, 391)
        Me.Panel1.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(258, 30)
        Me.Panel1.TabIndex = 14
        '
        'ButtonDelete
        '
        Me.ButtonDelete.BackColor = System.Drawing.SystemColors.ControlLight
        Me.ButtonDelete.Cursor = System.Windows.Forms.Cursors.Hand
        Me.ButtonDelete.Dock = System.Windows.Forms.DockStyle.Left
        Me.ButtonDelete.FlatAppearance.BorderColor = System.Drawing.SystemColors.Control
        Me.ButtonDelete.FlatAppearance.BorderSize = 2
        Me.ButtonDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ButtonDelete.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonDelete.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.ButtonDelete.Location = New System.Drawing.Point(192, 0)
        Me.ButtonDelete.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.ButtonDelete.Name = "ButtonDelete"
        Me.ButtonDelete.Size = New System.Drawing.Size(64, 30)
        Me.ButtonDelete.TabIndex = 17
        Me.ButtonDelete.Text = "Delete"
        Me.ButtonDelete.UseVisualStyleBackColor = False
        '
        'ButtonEdit
        '
        Me.ButtonEdit.BackColor = System.Drawing.SystemColors.ControlLight
        Me.ButtonEdit.Cursor = System.Windows.Forms.Cursors.Hand
        Me.ButtonEdit.Dock = System.Windows.Forms.DockStyle.Left
        Me.ButtonEdit.FlatAppearance.BorderColor = System.Drawing.SystemColors.Control
        Me.ButtonEdit.FlatAppearance.BorderSize = 2
        Me.ButtonEdit.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ButtonEdit.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonEdit.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.ButtonEdit.Location = New System.Drawing.Point(128, 0)
        Me.ButtonEdit.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.ButtonEdit.Name = "ButtonEdit"
        Me.ButtonEdit.Size = New System.Drawing.Size(64, 30)
        Me.ButtonEdit.TabIndex = 16
        Me.ButtonEdit.Text = "Edit"
        Me.ButtonEdit.UseVisualStyleBackColor = False
        '
        'ButtonSave
        '
        Me.ButtonSave.BackColor = System.Drawing.SystemColors.ControlLight
        Me.ButtonSave.Cursor = System.Windows.Forms.Cursors.Hand
        Me.ButtonSave.Dock = System.Windows.Forms.DockStyle.Left
        Me.ButtonSave.FlatAppearance.BorderColor = System.Drawing.SystemColors.Control
        Me.ButtonSave.FlatAppearance.BorderSize = 2
        Me.ButtonSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ButtonSave.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonSave.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.ButtonSave.Location = New System.Drawing.Point(64, 0)
        Me.ButtonSave.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.ButtonSave.Name = "ButtonSave"
        Me.ButtonSave.Size = New System.Drawing.Size(64, 30)
        Me.ButtonSave.TabIndex = 15
        Me.ButtonSave.Text = "Save"
        Me.ButtonSave.UseVisualStyleBackColor = False
        '
        'ButtonClear
        '
        Me.ButtonClear.BackColor = System.Drawing.SystemColors.ControlLight
        Me.ButtonClear.Cursor = System.Windows.Forms.Cursors.Hand
        Me.ButtonClear.Dock = System.Windows.Forms.DockStyle.Left
        Me.ButtonClear.FlatAppearance.BorderColor = System.Drawing.SystemColors.Control
        Me.ButtonClear.FlatAppearance.BorderSize = 2
        Me.ButtonClear.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ButtonClear.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonClear.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.ButtonClear.Location = New System.Drawing.Point(0, 0)
        Me.ButtonClear.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.ButtonClear.Name = "ButtonClear"
        Me.ButtonClear.Size = New System.Drawing.Size(64, 30)
        Me.ButtonClear.TabIndex = 0
        Me.ButtonClear.Text = "Clear"
        Me.ButtonClear.UseVisualStyleBackColor = False
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.Color.Red
        Me.Label9.Location = New System.Drawing.Point(120, 188)
        Me.Label9.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(14, 18)
        Me.Label9.TabIndex = 13
        Me.Label9.Text = "*"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.Color.Red
        Me.Label8.Location = New System.Drawing.Point(264, 330)
        Me.Label8.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(14, 18)
        Me.Label8.TabIndex = 12
        Me.Label8.Text = "*"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.Red
        Me.Label7.Location = New System.Drawing.Point(188, 260)
        Me.Label7.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(14, 18)
        Me.Label7.TabIndex = 11
        Me.Label7.Text = "*"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.Red
        Me.Label6.Location = New System.Drawing.Point(264, 123)
        Me.Label6.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(14, 18)
        Me.Label6.TabIndex = 10
        Me.Label6.Text = "*"
        '
        'ComboBoxType
        '
        Me.ComboBoxType.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.ComboBoxType.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.ComboBoxType.FormattingEnabled = True
        Me.ComboBoxType.Location = New System.Drawing.Point(18, 260)
        Me.ComboBoxType.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.ComboBoxType.Name = "ComboBoxType"
        Me.ComboBoxType.Size = New System.Drawing.Size(166, 23)
        Me.ComboBoxType.TabIndex = 9
        '
        'TextBoxSubType
        '
        Me.TextBoxSubType.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextBoxSubType.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.TextBoxSubType.Location = New System.Drawing.Point(18, 330)
        Me.TextBoxSubType.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.TextBoxSubType.Name = "TextBoxSubType"
        Me.TextBoxSubType.Size = New System.Drawing.Size(242, 21)
        Me.TextBoxSubType.TabIndex = 8
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(15, 308)
        Me.Label5.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(66, 15)
        Me.Label5.TabIndex = 7
        Me.Label5.Text = "Sub Type"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(15, 234)
        Me.Label4.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(37, 15)
        Me.Label4.TabIndex = 5
        Me.Label4.Text = "Type"
        '
        'TextBoxCode
        '
        Me.TextBoxCode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextBoxCode.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.TextBoxCode.Location = New System.Drawing.Point(18, 188)
        Me.TextBoxCode.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.TextBoxCode.Name = "TextBoxCode"
        Me.TextBoxCode.Size = New System.Drawing.Size(96, 21)
        Me.TextBoxCode.TabIndex = 4
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(15, 167)
        Me.Label3.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(40, 15)
        Me.Label3.TabIndex = 3
        Me.Label3.Text = "Code"
        '
        'TextBoxAccName
        '
        Me.TextBoxAccName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextBoxAccName.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.TextBoxAccName.Location = New System.Drawing.Point(18, 123)
        Me.TextBoxAccName.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.TextBoxAccName.Name = "TextBoxAccName"
        Me.TextBoxAccName.Size = New System.Drawing.Size(242, 21)
        Me.TextBoxAccName.TabIndex = 2
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(15, 101)
        Me.Label2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(99, 15)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Account Name"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Verdana", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(72, 30)
        Me.Label1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(156, 23)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Main Account"
        '
        'MainAccount
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1028, 543)
        Me.Controls.Add(Me.PanelMainGrid)
        Me.Controls.Add(Me.PanelMainForm)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.Name = "MainAccount"
        Me.ShowIcon = False
        Me.PanelMainGrid.ResumeLayout(False)
        Me.PanelMainGrid.PerformLayout()
        CType(Me.DataGridViewMain, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PanelMainForm.ResumeLayout(False)
        Me.PanelMainForm.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents TextBoxSearch As TextBox
    Friend WithEvents PanelMainGrid As Panel
    Friend WithEvents DataGridViewMain As DataGridView
    Friend WithEvents ButtonSearch As Button
    Friend WithEvents PanelMainForm As Panel
    Friend WithEvents Panel1 As Panel
    Friend WithEvents ButtonDelete As Button
    Friend WithEvents ButtonEdit As Button
    Friend WithEvents ButtonSave As Button
    Friend WithEvents ButtonClear As Button
    Friend WithEvents Label9 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents ComboBoxType As ComboBox
    Friend WithEvents TextBoxSubType As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents TextBoxCode As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents TextBoxAccName As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
End Class
