﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class SubAccount
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.PanelSubGrid = New System.Windows.Forms.Panel()
        Me.DataGridViewSub = New System.Windows.Forms.DataGridView()
        Me.ButtonSearch = New System.Windows.Forms.Button()
        Me.TextBoxSubSearch = New System.Windows.Forms.TextBox()
        Me.PanelSubForm = New System.Windows.Forms.Panel()
        Me.LabelSubType = New System.Windows.Forms.Label()
        Me.TextBoxSubCode = New System.Windows.Forms.TextBox()
        Me.ComboBoxCode = New System.Windows.Forms.ComboBox()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.ButtonDelete = New System.Windows.Forms.Button()
        Me.ButtonEdit = New System.Windows.Forms.Button()
        Me.ButtonSave = New System.Windows.Forms.Button()
        Me.ButtonClear = New System.Windows.Forms.Button()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.TextBoxSubAccName = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.TextBoxMainName = New System.Windows.Forms.TextBox()
        Me.PanelSubGrid.SuspendLayout()
        CType(Me.DataGridViewSub, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PanelSubForm.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'PanelSubGrid
        '
        Me.PanelSubGrid.BackColor = System.Drawing.Color.White
        Me.PanelSubGrid.Controls.Add(Me.DataGridViewSub)
        Me.PanelSubGrid.Controls.Add(Me.ButtonSearch)
        Me.PanelSubGrid.Controls.Add(Me.TextBoxSubSearch)
        Me.PanelSubGrid.Dock = System.Windows.Forms.DockStyle.Left
        Me.PanelSubGrid.Location = New System.Drawing.Point(0, 0)
        Me.PanelSubGrid.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.PanelSubGrid.Name = "PanelSubGrid"
        Me.PanelSubGrid.Size = New System.Drawing.Size(723, 543)
        Me.PanelSubGrid.TabIndex = 2
        '
        'DataGridViewSub
        '
        Me.DataGridViewSub.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridViewSub.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.DataGridViewSub.Location = New System.Drawing.Point(0, 30)
        Me.DataGridViewSub.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.DataGridViewSub.Name = "DataGridViewSub"
        Me.DataGridViewSub.RowHeadersWidth = 51
        Me.DataGridViewSub.RowTemplate.Height = 24
        Me.DataGridViewSub.Size = New System.Drawing.Size(723, 513)
        Me.DataGridViewSub.TabIndex = 1
        '
        'ButtonSearch
        '
        Me.ButtonSearch.BackColor = System.Drawing.Color.White
        Me.ButtonSearch.Cursor = System.Windows.Forms.Cursors.Hand
        Me.ButtonSearch.FlatAppearance.BorderSize = 0
        Me.ButtonSearch.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ButtonSearch.Font = New System.Drawing.Font("Verdana", 9.5!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonSearch.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.ButtonSearch.Location = New System.Drawing.Point(647, 2)
        Me.ButtonSearch.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.ButtonSearch.Name = "ButtonSearch"
        Me.ButtonSearch.Size = New System.Drawing.Size(74, 25)
        Me.ButtonSearch.TabIndex = 4
        Me.ButtonSearch.Text = "Search"
        Me.ButtonSearch.UseVisualStyleBackColor = False
        '
        'TextBoxSubSearch
        '
        Me.TextBoxSubSearch.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextBoxSubSearch.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxSubSearch.Location = New System.Drawing.Point(459, 4)
        Me.TextBoxSubSearch.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.TextBoxSubSearch.Name = "TextBoxSubSearch"
        Me.TextBoxSubSearch.Size = New System.Drawing.Size(184, 23)
        Me.TextBoxSubSearch.TabIndex = 3
        '
        'PanelSubForm
        '
        Me.PanelSubForm.BackColor = System.Drawing.SystemColors.Control
        Me.PanelSubForm.Controls.Add(Me.TextBoxMainName)
        Me.PanelSubForm.Controls.Add(Me.LabelSubType)
        Me.PanelSubForm.Controls.Add(Me.TextBoxSubCode)
        Me.PanelSubForm.Controls.Add(Me.ComboBoxCode)
        Me.PanelSubForm.Controls.Add(Me.Panel1)
        Me.PanelSubForm.Controls.Add(Me.Label9)
        Me.PanelSubForm.Controls.Add(Me.Label8)
        Me.PanelSubForm.Controls.Add(Me.Label7)
        Me.PanelSubForm.Controls.Add(Me.Label6)
        Me.PanelSubForm.Controls.Add(Me.TextBoxSubAccName)
        Me.PanelSubForm.Controls.Add(Me.Label5)
        Me.PanelSubForm.Controls.Add(Me.Label4)
        Me.PanelSubForm.Controls.Add(Me.Label3)
        Me.PanelSubForm.Controls.Add(Me.Label2)
        Me.PanelSubForm.Controls.Add(Me.Label1)
        Me.PanelSubForm.Dock = System.Windows.Forms.DockStyle.Right
        Me.PanelSubForm.Location = New System.Drawing.Point(727, 0)
        Me.PanelSubForm.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.PanelSubForm.Name = "PanelSubForm"
        Me.PanelSubForm.Size = New System.Drawing.Size(301, 543)
        Me.PanelSubForm.TabIndex = 3
        '
        'LabelSubType
        '
        Me.LabelSubType.AutoSize = True
        Me.LabelSubType.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelSubType.Location = New System.Drawing.Point(122, 167)
        Me.LabelSubType.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.LabelSubType.Name = "LabelSubType"
        Me.LabelSubType.Size = New System.Drawing.Size(0, 13)
        Me.LabelSubType.TabIndex = 17
        '
        'TextBoxSubCode
        '
        Me.TextBoxSubCode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextBoxSubCode.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.TextBoxSubCode.Location = New System.Drawing.Point(16, 258)
        Me.TextBoxSubCode.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.TextBoxSubCode.Name = "TextBoxSubCode"
        Me.TextBoxSubCode.Size = New System.Drawing.Size(148, 21)
        Me.TextBoxSubCode.TabIndex = 16
        '
        'ComboBoxCode
        '
        Me.ComboBoxCode.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.ComboBoxCode.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.ComboBoxCode.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.ComboBoxCode.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.ComboBoxCode.FormattingEnabled = True
        Me.ComboBoxCode.Location = New System.Drawing.Point(16, 120)
        Me.ComboBoxCode.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.ComboBoxCode.Name = "ComboBoxCode"
        Me.ComboBoxCode.Size = New System.Drawing.Size(144, 23)
        Me.ComboBoxCode.TabIndex = 15
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.ButtonDelete)
        Me.Panel1.Controls.Add(Me.ButtonEdit)
        Me.Panel1.Controls.Add(Me.ButtonSave)
        Me.Panel1.Controls.Add(Me.ButtonClear)
        Me.Panel1.Location = New System.Drawing.Point(25, 392)
        Me.Panel1.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(246, 30)
        Me.Panel1.TabIndex = 14
        '
        'ButtonDelete
        '
        Me.ButtonDelete.BackColor = System.Drawing.SystemColors.ControlLight
        Me.ButtonDelete.Cursor = System.Windows.Forms.Cursors.Hand
        Me.ButtonDelete.Dock = System.Windows.Forms.DockStyle.Left
        Me.ButtonDelete.FlatAppearance.BorderColor = System.Drawing.SystemColors.Control
        Me.ButtonDelete.FlatAppearance.BorderSize = 2
        Me.ButtonDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ButtonDelete.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Bold)
        Me.ButtonDelete.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.ButtonDelete.Location = New System.Drawing.Point(177, 0)
        Me.ButtonDelete.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.ButtonDelete.Name = "ButtonDelete"
        Me.ButtonDelete.Size = New System.Drawing.Size(66, 30)
        Me.ButtonDelete.TabIndex = 17
        Me.ButtonDelete.Text = "Delete"
        Me.ButtonDelete.UseVisualStyleBackColor = False
        '
        'ButtonEdit
        '
        Me.ButtonEdit.BackColor = System.Drawing.SystemColors.ControlLight
        Me.ButtonEdit.Cursor = System.Windows.Forms.Cursors.Hand
        Me.ButtonEdit.Dock = System.Windows.Forms.DockStyle.Left
        Me.ButtonEdit.FlatAppearance.BorderColor = System.Drawing.SystemColors.Control
        Me.ButtonEdit.FlatAppearance.BorderSize = 2
        Me.ButtonEdit.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ButtonEdit.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Bold)
        Me.ButtonEdit.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.ButtonEdit.Location = New System.Drawing.Point(118, 0)
        Me.ButtonEdit.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.ButtonEdit.Name = "ButtonEdit"
        Me.ButtonEdit.Size = New System.Drawing.Size(59, 30)
        Me.ButtonEdit.TabIndex = 16
        Me.ButtonEdit.Text = "Edit"
        Me.ButtonEdit.UseVisualStyleBackColor = False
        '
        'ButtonSave
        '
        Me.ButtonSave.BackColor = System.Drawing.SystemColors.ControlLight
        Me.ButtonSave.Cursor = System.Windows.Forms.Cursors.Hand
        Me.ButtonSave.Dock = System.Windows.Forms.DockStyle.Left
        Me.ButtonSave.FlatAppearance.BorderColor = System.Drawing.SystemColors.Control
        Me.ButtonSave.FlatAppearance.BorderSize = 2
        Me.ButtonSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ButtonSave.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Bold)
        Me.ButtonSave.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.ButtonSave.Location = New System.Drawing.Point(59, 0)
        Me.ButtonSave.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.ButtonSave.Name = "ButtonSave"
        Me.ButtonSave.Size = New System.Drawing.Size(59, 30)
        Me.ButtonSave.TabIndex = 15
        Me.ButtonSave.Text = "Save"
        Me.ButtonSave.UseVisualStyleBackColor = False
        '
        'ButtonClear
        '
        Me.ButtonClear.BackColor = System.Drawing.SystemColors.ControlLight
        Me.ButtonClear.Cursor = System.Windows.Forms.Cursors.Hand
        Me.ButtonClear.Dock = System.Windows.Forms.DockStyle.Left
        Me.ButtonClear.FlatAppearance.BorderColor = System.Drawing.SystemColors.Control
        Me.ButtonClear.FlatAppearance.BorderSize = 2
        Me.ButtonClear.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ButtonClear.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonClear.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.ButtonClear.Location = New System.Drawing.Point(0, 0)
        Me.ButtonClear.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.ButtonClear.Name = "ButtonClear"
        Me.ButtonClear.Size = New System.Drawing.Size(59, 30)
        Me.ButtonClear.TabIndex = 0
        Me.ButtonClear.Text = "Clear"
        Me.ButtonClear.UseVisualStyleBackColor = False
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.Color.Red
        Me.Label9.Location = New System.Drawing.Point(231, 187)
        Me.Label9.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(14, 18)
        Me.Label9.TabIndex = 13
        Me.Label9.Text = "*"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.Color.Red
        Me.Label8.Location = New System.Drawing.Point(268, 328)
        Me.Label8.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(14, 18)
        Me.Label8.TabIndex = 12
        Me.Label8.Text = "*"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.Red
        Me.Label7.Location = New System.Drawing.Point(169, 258)
        Me.Label7.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(14, 18)
        Me.Label7.TabIndex = 11
        Me.Label7.Text = "*"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.Red
        Me.Label6.Location = New System.Drawing.Point(164, 120)
        Me.Label6.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(14, 18)
        Me.Label6.TabIndex = 10
        Me.Label6.Text = "*"
        '
        'TextBoxSubAccName
        '
        Me.TextBoxSubAccName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextBoxSubAccName.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.TextBoxSubAccName.Location = New System.Drawing.Point(16, 328)
        Me.TextBoxSubAccName.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.TextBoxSubAccName.Name = "TextBoxSubAccName"
        Me.TextBoxSubAccName.Size = New System.Drawing.Size(247, 21)
        Me.TextBoxSubAccName.TabIndex = 8
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(14, 306)
        Me.Label5.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(99, 15)
        Me.Label5.TabIndex = 7
        Me.Label5.Text = "Sub A/C Name"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(14, 232)
        Me.Label4.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(69, 15)
        Me.Label4.TabIndex = 5
        Me.Label4.Text = "Sub Code"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(14, 165)
        Me.Label3.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(106, 15)
        Me.Label3.TabIndex = 3
        Me.Label3.Text = "Main A/C Name"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(14, 99)
        Me.Label2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(76, 15)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Main Code"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Verdana", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(80, 30)
        Me.Label1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(145, 23)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Sub Account"
        '
        'TextBoxMainName
        '
        Me.TextBoxMainName.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxMainName.Location = New System.Drawing.Point(17, 187)
        Me.TextBoxMainName.Margin = New System.Windows.Forms.Padding(2)
        Me.TextBoxMainName.Name = "TextBoxMainName"
        Me.TextBoxMainName.Size = New System.Drawing.Size(210, 21)
        Me.TextBoxMainName.TabIndex = 20
        '
        'SubAccount
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1028, 543)
        Me.Controls.Add(Me.PanelSubGrid)
        Me.Controls.Add(Me.PanelSubForm)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.Name = "SubAccount"
        Me.ShowIcon = False
        Me.Text = "Sub_Account"
        Me.PanelSubGrid.ResumeLayout(False)
        Me.PanelSubGrid.PerformLayout()
        CType(Me.DataGridViewSub, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PanelSubForm.ResumeLayout(False)
        Me.PanelSubForm.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents PanelSubGrid As Panel
    Friend WithEvents DataGridViewSub As DataGridView
    Friend WithEvents ButtonSearch As Button
    Friend WithEvents TextBoxSubSearch As TextBox
    Friend WithEvents PanelSubForm As Panel
    Friend WithEvents TextBoxSubCode As TextBox
    Friend WithEvents ComboBoxCode As ComboBox
    Friend WithEvents Panel1 As Panel
    Friend WithEvents ButtonDelete As Button
    Friend WithEvents ButtonEdit As Button
    Friend WithEvents ButtonSave As Button
    Friend WithEvents ButtonClear As Button
    Friend WithEvents Label9 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents TextBoxSubAccName As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents LabelSubType As Label
    Friend WithEvents TextBoxMainName As System.Windows.Forms.TextBox
End Class
